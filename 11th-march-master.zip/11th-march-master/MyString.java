
public interface MyString {
	String myStringFunction(String s);
}
