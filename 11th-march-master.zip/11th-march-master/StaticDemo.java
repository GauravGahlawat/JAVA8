package JavaFeatures;

public class StaticDemo {

	public static void main(String[] args) {
		 double var1= Math.sqrt(5.0);
	      double var2= Math.tan(30);
	      System.out.println("Square of 5 is:"+ var1);
	      System.out.println("Tan of 30 is:"+ var2);

	}

}
